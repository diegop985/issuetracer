//Padre container de casi todas las opciones :D
const container = document.getElementById("container") 
const btnCreateIssue = document.getElementById("create-issue-btn") 

const issuesArray = []